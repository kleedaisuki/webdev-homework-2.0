/* 王艺霖 2410824 · 在学院真实通知列表页运行；再次执行会先恢复旧状态。 */
(() => {
  'use strict';
  if (location.hostname !== 'cc.nankai.edu.cn' || location.pathname !== '/13293/list.htm') {
    alert('请先打开 https://cc.nankai.edu.cn/13293/list.htm'); return;
  }
  const $ = window.jQuery;
  if (!$) { alert('页面的 jQuery 尚未加载，请刷新后重试。'); return; }
  window.NKUHomeworkLab?.destroy();
  const $rows = $('#wp_news_w49 tr[onclick*="page.htm"]');
  if (!$rows.length) { alert('没有找到通知表格；网站结构可能已变化。'); return; }
  const originals = $rows.toArray().map(row => ({ row, style: row.getAttribute('style'), cellStyles: [...row.cells].map(c => c.getAttribute('style')) }));
  const $panel = $('<section id="nku-hw1-panel" aria-label="jQuery 通知实验"></section>').css({padding:'18px',marginBottom:'16px',background:'#f0eafa',border:'1px solid #c9b4de',borderRadius:'8px'});
  const $heading = $('<h2 id="nku-hw1-heading"></h2>').text('学生工作通知 · jQuery 实验').css({fontSize:'21px',margin:'0 0 12px',color:'#54266e'});
  const $input = $('<input id="nku-hw1-keywords" aria-label="重点关键词">').val('毕业生 就业').css({padding:'8px',marginRight:'10px',width:'230px'});
  const $button = $('<button type="button" id="nku-hw1-toggle"></button>').text('开启重点浏览').css({padding:'9px 16px',background:'#652d86',color:'white',border:0,borderRadius:'5px'});
  const $status = $('<p id="nku-hw1-status" aria-live="polite"></p>').text(`当前显示全部 ${$rows.length} 条通知；关键词用空格分隔。`).css({margin:'12px 0 0'});
  $panel.append($heading,$input,$button,$status).insertBefore($('#wp_news_w49').closest('.table-responsive'));
  let active = false;
  function restore() {
    originals.forEach(({row,style,cellStyles}) => {
      style === null ? row.removeAttribute('style') : row.setAttribute('style',style);
      [...row.cells].forEach((cell,i) => cellStyles[i] === null ? cell.removeAttribute('style') : cell.setAttribute('style',cellStyles[i]));
    });
    $heading.text('学生工作通知 · jQuery 实验');
    $status.text(`当前显示全部 ${$rows.length} 条通知；关键词用空格分隔。`);
    $button.text('开启重点浏览'); $input.prop('disabled',false); active = false;
  }
  $button.on('click.nkuHomework', function () {
    if (active) { restore(); return; }
    const keywords = String($input.val()).trim().split(/[\s,，]+/).filter(Boolean);
    if (!keywords.length) { $status.text('请先输入至少一个关键词。'); return; }
    const $matched = $rows.filter(function () {
      const title = $(this).find('td.text-align-title').text();
      return keywords.some(word => title.includes(word));
    });
    // click 回调：更新文字、样式、显示状态、计数和按钮文本。
    $heading.text('学生工作通知 · 重点浏览模式已开启');                     // 1. 改文字
    $matched.children('td').css({backgroundColor:'#fff2b3',fontWeight:'700'}); // 2. 改样式
    $rows.not($matched).hide();                                           // 3. 隐藏非匹配行
    $status.text(`匹配 ${$matched.length} / ${$rows.length} 条：${keywords.join('、')}`); // 4. 反馈数量
    $(this).text('恢复全部通知');                                         // 5. 改按钮文字
    $input.prop('disabled',true); active = true;
  });
  window.NKUHomeworkLab = { destroy() { restore(); $panel.remove(); delete window.NKUHomeworkLab; } };
  console.info('jQuery 实验已准备就绪，版本：'+$.fn.jquery+'；请点击“开启重点浏览”。');
})();
