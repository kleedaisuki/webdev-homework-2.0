import base64, json
from pathlib import Path
from urllib.parse import parse_qs
request = Path(__file__).with_name('03-post-keyword-search.request.txt').read_text(encoding='utf-8')
body = request.split('\n\n',1)[1]
print(json.dumps(json.loads(base64.b64decode(parse_qs(body)['searchInfo'][0])),ensure_ascii=False,indent=2))
