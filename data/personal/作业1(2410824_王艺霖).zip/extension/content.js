/* 王艺霖 2410824 · 适配首页链接、onclick 表格行和通知详情页。 */
(() => {
  'use strict';
  if (globalThis.__nkuNoticeHelper) return;
  globalThis.__nkuNoticeHelper = true;
  function canonical(raw) {
    try {const u=new URL(raw,location.href); return u.hostname==='cc.nankai.edu.cn' && ['http:','https:'].includes(u.protocol) && /\/c\d+a\d+\/page\.htm$/.test(u.pathname) ? 'https://cc.nankai.edu.cn'+u.pathname : null;} catch {return null;}
  }
  const currentUrl = canonical(location.href);
  const title = (document.querySelector('.news-detail-title,.arti_title,h1')?.textContent || document.title).trim();
  async function message(data) {
    const result = await chrome.runtime.sendMessage(data);
    if (!result?.ok) throw Error(result?.error || '扩展未响应，请刷新页面。');
    return result;
  }
  let records = {};
  function decorate() {
    for (const host of document.querySelectorAll('a[href],tr[onclick]')) {
      const raw = host.tagName === 'A' ? host.getAttribute('href') : host.getAttribute('onclick')?.match(/location(?:\.href)?\s*=\s*['"]([^'"]+)['"]/)?.[1];
      const url = raw && canonical(raw);
      if (!url) continue;
      const target = host.tagName === 'TR' ? host.querySelector('td.text-align-title,td:nth-child(2)') : host;
      if (!target) continue;
      let badge = target.querySelector('.nku-notice-status');
      const rec = records[url]; const text = [rec?.favorite?'★ 已收藏':'',rec?.read?'✓ 已读':''].filter(Boolean).join(' · ');
      if (!text) { badge?.remove(); continue; }
      if (!badge) {badge=document.createElement('span');badge.className='nku-notice-status';target.appendChild(badge);}
      if (badge.textContent!==text) badge.textContent=text;
    }
    if (currentUrl && document.getElementById('nku-notice-toolbar')) {
      const rec = records[currentUrl];
      document.getElementById('nku-notice-favorite').textContent=rec?.favorite?'取消收藏':'收藏这篇通知';
      document.getElementById('nku-notice-read').textContent=rec?.read?'标为未读':'标记已读';
      document.getElementById('nku-notice-state').textContent=[rec?.favorite?'已收藏':'未收藏',rec?.read?'已读':'未读'].join(' / ');
    }
  }
  async function refresh() {records=(await message({type:'GET_RECORDS'})).records;decorate();}
  if (currentUrl) {
    const toolbar = document.createElement('aside');toolbar.id='nku-notice-toolbar';toolbar.setAttribute('aria-label','学院通知收藏助手');
    const label=document.createElement('strong');label.textContent='计院通知助手';
    const favorite=document.createElement('button');favorite.id='nku-notice-favorite';favorite.type='button';favorite.textContent='收藏这篇通知';
    const read=document.createElement('button');read.id='nku-notice-read';read.type='button';read.textContent='标记已读';
    const state=document.createElement('span');state.id='nku-notice-state';state.setAttribute('aria-live','polite');
    toolbar.append(label,favorite,read,state);document.body.appendChild(toolbar);
    async function toggle(key,button) {
      button.disabled=true;
      try {const response=await message({type:'PATCH_RECORD',url:currentUrl,title,[key]:!records[currentUrl]?.[key]});records=response.records;decorate();}
      catch(error){state.textContent=error.message;}finally{button.disabled=false;}
    }
    favorite.addEventListener('click',()=>toggle('favorite',favorite));
    read.addEventListener('click',()=>toggle('read',read));
  }
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(message.type==='GET_CURRENT_NOTICE'){respond({url:currentUrl,title});return false;}
  });
  chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.records){records=changes.records.newValue||{};decorate();}});
  let timer;
  const observer = new MutationObserver(mutations=>{
    if(mutations.some(m=>[...m.addedNodes].some(n=>n.nodeType===1 && !n.closest?.('#nku-notice-toolbar,.nku-notice-status')))) {
      clearTimeout(timer);timer=setTimeout(decorate,100);
    }
  });
  observer.observe(document.body,{childList:true,subtree:true});
  refresh().catch(error=>console.warn('计院通知助手：',error.message));
})();
