/* 王艺霖 2410824 · storage 写操作串行，避免快速点击覆盖其他记录。 */
'use strict';
let queue = Promise.resolve();
function canonical(raw) {
  const u = new URL(raw);
  if (u.hostname !== 'cc.nankai.edu.cn' || !['http:','https:'].includes(u.protocol) || !/\/c\d+a\d+\/page\.htm$/.test(u.pathname)) throw Error('仅支持学院通知或新闻详情页。');
  return 'https://cc.nankai.edu.cn' + u.pathname;
}
async function processMessage(message) {
  const records = (await chrome.storage.local.get('records')).records || {};
  if (message.type === 'GET_RECORDS') return {ok:true,records};
  const url = canonical(message.url);
  if (message.type === 'DELETE_RECORD') { delete records[url]; }
  else if (message.type === 'PATCH_RECORD') {
    const now = new Date().toISOString();
    const old = records[url] || {url,title:url,favorite:false,read:false,createdAt:now};
    const record = {...old,updatedAt:now};
    if (typeof message.title === 'string' && message.title.trim()) record.title = message.title.trim().slice(0,500);
    for (const key of ['favorite','read']) if (typeof message[key] === 'boolean') record[key] = message[key];
    records[url] = record;
  } else throw Error('未知操作');
  await chrome.storage.local.set({records});
  return {ok:true,records};
}
chrome.runtime.onMessage.addListener((message,sender,sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  queue = queue.then(() => processMessage(message)).then(sendResponse,error => sendResponse({ok:false,error:error.message}));
  return true;
});
