'use strict';
const $=id=>document.getElementById(id);
let current=null,records={};
async function request(data){const response=await chrome.runtime.sendMessage(data);if(!response?.ok)throw Error(response?.error||'扩展未响应');return response;}
function status(text){$('feedback').textContent=text;}
function render(){
  const needle=$('search').value.trim().toLocaleLowerCase();
  const all=Object.values(records).filter(r=>r.favorite).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  const visible=all.filter(r=>r.title.toLocaleLowerCase().includes(needle)&&(!$('unread-only').checked||!r.read));
  $('count').textContent=`${all.length} 篇收藏 · 显示 ${visible.length} 篇`;
  $('records').replaceChildren();
  if(!visible.length){const p=document.createElement('p');p.className='empty';p.textContent=all.length?'没有匹配的收藏。':'暂无收藏，打开学院通知后点击收藏。';$('records').append(p);}
  for(const rec of visible){
    const card=document.createElement('article');card.className='record';card.dataset.url=rec.url;
    const link=document.createElement('a');link.textContent=rec.title;link.href=rec.url;link.target='_blank';link.rel='noopener';
    link.addEventListener('click',event=>{event.preventDefault();chrome.tabs.create({url:rec.url});});
    const meta=document.createElement('small');meta.textContent=`${rec.read?'✓ 已读':'○ 未读'} · 收藏于 ${new Date(rec.createdAt).toLocaleString('zh-CN')}`;
    const actions=document.createElement('div');actions.className='actions';
    const mark=document.createElement('button');mark.className='secondary';mark.textContent=rec.read?'标为未读':'标记已读';
    mark.addEventListener('click',()=>act({type:'PATCH_RECORD',url:rec.url,read:!rec.read},'阅读状态已更新'));
    const remove=document.createElement('button');remove.className='delete';remove.textContent='取消收藏';
    remove.addEventListener('click',()=>act({type:'PATCH_RECORD',url:rec.url,favorite:false},'已取消收藏，阅读状态保留'));
    const forget=document.createElement('button');forget.className='delete';forget.textContent='删除记录';
    forget.addEventListener('click',()=>act({type:'DELETE_RECORD',url:rec.url},'记录已删除'));
    actions.append(mark,remove,forget);card.append(link,meta,actions);$('records').append(card);
  }
  if(current?.url){const rec=records[current.url];$('save-current').textContent=rec?.favorite?'取消当前收藏':'收藏当前通知';$('read-current').textContent=rec?.read?'标为未读':'标记已读';}
}
async function act(data,text){try{records=(await request(data)).records;render();status(text);}catch(error){status(error.message);}}
$('search').addEventListener('input',render);$('unread-only').addEventListener('change',render);
$('save-current').addEventListener('click',()=>current?.url&&act({type:'PATCH_RECORD',...current,favorite:!records[current.url]?.favorite},'收藏状态已更新'));
$('read-current').addEventListener('click',()=>current?.url&&act({type:'PATCH_RECORD',...current,read:!records[current.url]?.read},'阅读状态已更新'));
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.records){records=changes.records.newValue||{};render();}});
(async()=>{
  try{
    records=(await request({type:'GET_RECORDS'})).records;
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(tab?.id&&/^https?:\/\/cc\.nankai\.edu\.cn\//.test(tab.url||'')){
      try{current=await chrome.tabs.sendMessage(tab.id,{type:'GET_CURRENT_NOTICE'});}catch{status('刚加载扩展？请刷新学院网页后重新打开。');}
    }
    if(current?.url){$('current-title').textContent=current.title;$('save-current').disabled=false;$('read-current').disabled=false;}
    else $('current-title').textContent='请在学院通知详情页收藏；已有收藏仍可在下方管理。';
    render();
  }catch(error){status(error.message);}
})();
