<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$root=dirname(__DIR__);$s=json_decode(file_get_contents(__DIR__.'/settings.json'),true,512,JSON_THROW_ON_ERROR);
$done=is_file(__DIR__.'/restored.flag');
$db=new mysqli('127.0.0.1','root',$done?$s['rootPassword']:'','',$s['dbPort']);
$db->set_charset('utf8mb4');
if(!$done){
 $db->query('CREATE DATABASE IF NOT EXISTS wordpress_hw3 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
 $db->query("CREATE USER IF NOT EXISTS 'wp_hw3'@'127.0.0.1' IDENTIFIED BY '".$db->real_escape_string($s['dbPassword'])."'");
 $db->query("GRANT ALL ON wordpress_hw3.* TO 'wp_hw3'@'127.0.0.1'");
 $db->select_db('wordpress_hw3');
 $db->multi_query(file_get_contents($root.'/database/wordpress.sql'));
 do {if($result=$db->store_result())$result->free();}while($db->more_results() && $db->next_result());
 $db->query("ALTER USER 'root'@'localhost' IDENTIFIED BY '".$db->real_escape_string($s['rootPassword'])."'");
 file_put_contents(__DIR__.'/restored.flag','SQL import complete');
}
$db->close();echo "WordPress database ready.\n";
