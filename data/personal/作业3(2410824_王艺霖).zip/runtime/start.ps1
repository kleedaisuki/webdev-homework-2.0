﻿param([string]$PhpPath='', [string]$MySqlBase='C:\Program Files\MySQL\MySQL Server 8.0', [int]$WebPort=8086, [int]$DbPort=3336)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
if(!$PhpPath){$search=Get-Item $root;while($search -and !$PhpPath){$candidate=Join-Path $search.FullName 'software\php\php.exe';if(Test-Path -LiteralPath $candidate){$PhpPath=$candidate};$search=$search.Parent}}
if(!$PhpPath){$found=Get-Command php -ErrorAction SilentlyContinue;if($found){$PhpPath=$found.Source}}
if(!$PhpPath -or !(Test-Path -LiteralPath $PhpPath)){throw 'Specify -PhpPath with the full path to PHP 8.3 php.exe.'}
$mysqld=Join-Path $MySqlBase 'bin\mysqld.exe'
if(!(Test-Path -LiteralPath $mysqld)){throw 'Specify -MySqlBase with the MySQL 8.0 installation directory.'}
function Test-Port([int]$Port){$c=[Net.Sockets.TcpClient]::new();try{$a=$c.BeginConnect('127.0.0.1',$Port,$null,$null);if(!$a.AsyncWaitHandle.WaitOne(200)){return $false};$c.EndConnect($a);return $true}catch{return $false}finally{$c.Dispose()}}
if((Test-Port $DbPort) -or (Test-Port $WebPort)){throw 'A requested port is occupied. Stop that instance or choose -WebPort and -DbPort.'}
$utf8=[Text.UTF8Encoding]::new($false)
$settingsPath=Join-Path $PSScriptRoot 'settings.json'
if(!(Test-Path -LiteralPath $settingsPath)){
 $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
 function New-Secret {$bytes=New-Object byte[] 32;$rng.GetBytes($bytes);return ([BitConverter]::ToString($bytes)).Replace('-','').ToLower()}
 $settings=@{dbPassword=(New-Secret);rootPassword=(New-Secret);salts=@()}
 for($i=0;$i -lt 8;$i++){$settings.salts+=(New-Secret)}
 $settings.webPort=$WebPort;$settings.dbPort=$DbPort
 [IO.File]::WriteAllText($settingsPath,($settings|ConvertTo-Json),$utf8)
}
$settings=Get-Content -LiteralPath $settingsPath -Raw|ConvertFrom-Json
if($settings.webPort -ne $WebPort -or $settings.dbPort -ne $DbPort){throw 'Use the same ports as the first initialization (see runtime/settings.json).'}
$data=Join-Path $root 'database\mysql'
$unixData=$data.Replace('\','/');$unixRuntime=$PSScriptRoot.Replace('\','/')
$ini="[mysqld]`nbasedir=`"$($MySqlBase.Replace('\','/'))`"`ndatadir=`"$unixData`"`nport=$DbPort`nbind-address=127.0.0.1`nmysqlx=OFF`ncharacter-set-server=utf8mb4`ncollation-server=utf8mb4_unicode_ci`ninnodb_buffer_pool_size=64M`nlog-error=`"$unixRuntime/mysql-error.log`"`npid-file=`"$unixRuntime/mysql.pid`"`n"
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'my.ini'),$ini,$utf8)
$ext=(Join-Path (Split-Path $PhpPath -Parent) 'ext').Replace('\','/')
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'php.ini'),"extension_dir=`"$ext`"`nextension=mysqli`nextension=mbstring`nextension=openssl`nextension=curl`nextension=fileinfo`nextension=gd`nextension=zip`ndate.timezone=Asia/Shanghai`nmemory_limit=256M`n",$utf8)
if(!(Test-Path -LiteralPath (Join-Path $data 'mysql'))){
 New-Item -ItemType Directory -Path $data -Force|Out-Null
 & $mysqld "--defaults-file=$PSScriptRoot\my.ini" --initialize-insecure
 if($LASTEXITCODE -ne 0){throw 'MySQL initialization failed. See runtime/mysql-error.log.'}
}
Start-Process -WindowStyle Hidden -FilePath $mysqld -ArgumentList @('--defaults-file=runtime/my.ini') -WorkingDirectory $root
for($i=0;$i -lt 80;$i++){if(Test-Port $DbPort){break};Start-Sleep -Milliseconds 250}
if(!(Test-Port $DbPort)){throw 'MySQL did not start. See runtime/mysql-error.log.'}
& $PhpPath -c "$PSScriptRoot\php.ini" "$PSScriptRoot\restore.php"
if($LASTEXITCODE -ne 0){throw 'Database restore failed. Run runtime/stop.ps1 before retrying.'}
$admin="[client]`nuser=root`npassword=$($settings.rootPassword)`nhost=127.0.0.1`nport=$DbPort`n"
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'database-admin.cnf'),$admin,$utf8)
$process=Start-Process -WindowStyle Hidden -FilePath $PhpPath -ArgumentList @('-c','runtime/php.ini','-S',"127.0.0.1:$WebPort",'-t','wordpress') -WorkingDirectory $root -RedirectStandardOutput (Join-Path $PSScriptRoot 'php-server.log') -RedirectStandardError (Join-Path $PSScriptRoot 'php-server-error.log') -PassThru
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'php.pid'),[string]$process.Id)
for($i=0;$i -lt 30;$i++){if(Test-Port $WebPort){break};Start-Sleep -Milliseconds 200}
if(!(Test-Port $WebPort)){throw 'PHP did not start. See runtime/php-server-error.log.'}
Write-Host "Home: http://127.0.0.1:$WebPort/"
Write-Host "Admin: http://127.0.0.1:$WebPort/wp-admin/"
