﻿param([string]$MySqlBase='C:\Program Files\MySQL\MySQL Server 8.0')
$ErrorActionPreference='Stop'
$pidFile=Join-Path $PSScriptRoot 'php.pid'
if(Test-Path -LiteralPath $pidFile){$serverId=[int](Get-Content -LiteralPath $pidFile);$p=Get-Process -Id $serverId -ErrorAction SilentlyContinue;if($p -and $p.ProcessName -eq 'php'){Stop-Process -Id $serverId};Remove-Item -LiteralPath $pidFile}
$admin=Join-Path $PSScriptRoot 'database-admin.cnf'
if(Test-Path -LiteralPath $admin){& (Join-Path $MySqlBase 'bin\mysqladmin.exe') "--defaults-extra-file=$admin" shutdown}
