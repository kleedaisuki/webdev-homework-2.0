<?php
$courseworkConfig=json_decode(file_get_contents(dirname(__DIR__).'/runtime/settings.json'),true,512,JSON_THROW_ON_ERROR);
define('DB_NAME','wordpress_hw3');define('DB_USER','wp_hw3');define('DB_PASSWORD',$courseworkConfig['dbPassword']);
define('DB_HOST','127.0.0.1:'.$courseworkConfig['dbPort']);define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');
foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $i=>$key)define($key,$courseworkConfig['salts'][$i]);
define('WP_HOME','http://127.0.0.1:'.$courseworkConfig['webPort']);define('WP_SITEURL',WP_HOME);
define('WP_HTTP_BLOCK_EXTERNAL',true);define('DISABLE_WP_CRON',true);define('AUTOMATIC_UPDATER_DISABLED',true);define('WP_AUTO_UPDATE_CORE',false);define('WP_DEBUG',false);
$table_prefix='wp_';unset($courseworkConfig);
if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';
